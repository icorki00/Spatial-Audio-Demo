-- Android Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    libdirs(wwiseSDKEnv .. "/%{cfg.platform}_%{cfg.architecture}/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
    files
    {
        "../Android/AkFileHelpers.cpp",
    }

    excludes
    {
        "../Common/AkMultipleFileLocation.cpp",
    }

    includedirs
    {
        wwiseSDKEnv .. "/samples/SoundEngine/Android/libzip/lib",
    }

    links
    {
        "OpenSLES",
        "android",
        "log",
        "dl",
        "zip",
        "z"
    }

    linkoptions
	{
                "-L" .. wwiseSDKEnv .. "/Android_$(TARGET_ARCH_ABI)/$(CONFIGURATION)/lib/",
                "-Wl,--as-needed"
	}

    -- Enable symbol stripping on all targets. ndk-build generate a non-stripped version of the library in its out folder
    symbols "Off"
end

return platform